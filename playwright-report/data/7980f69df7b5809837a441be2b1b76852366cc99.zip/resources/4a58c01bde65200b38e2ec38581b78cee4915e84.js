(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0i3x-y0._.js","static/chunks/node_modules_next_0ox~b09._.js","static/chunks/0axv_zod_v3_0qkynqf._.js","static/chunks/node_modules_@insforge_shared-schemas_dist_0dr3hty._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_@base-ui_react_esm_0660x8d._.js","static/chunks/node_modules_00ff41q._.js"],
    source: "dynamic"
});
