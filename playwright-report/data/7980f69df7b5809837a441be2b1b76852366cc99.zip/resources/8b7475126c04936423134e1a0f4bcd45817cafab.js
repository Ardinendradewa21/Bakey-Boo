(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_078l.vf._.js","static/chunks/node_modules_next_0mgv4n8._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_@base-ui_react_esm_internals_0xu4p3o._.js","static/chunks/node_modules_@base-ui_react_esm_utils_0h.pl~7._.js","static/chunks/node_modules_@base-ui_react_esm_floating-ui-react_0h12xmi._.js","static/chunks/node_modules_@base-ui_react_esm_menu_04s~gix._.js","static/chunks/node_modules_@base-ui_react_esm_0jkqnkn._.js","static/chunks/0axv_zod_v3_0qkynqf._.js","static/chunks/node_modules_@insforge_shared-schemas_dist_0dr3hty._.js","static/chunks/node_modules_0s18039._.js"],
    source: "dynamic"
});
